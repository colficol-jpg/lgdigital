const products = [
  {
    id: 1,
    name: "LG OLED C3 55''",
    description: "Televisor OLED 4K Smart con IA α9 Gen6",
    price: "4.299.000",
    image: "/televisores/lg.jpg"
  },
  {
    id: 2,
    name: "LG QNED 65''",
    description: "Resolución 4K UHD con Quantum Dot NanoCell",
    price: "5.199.000",
    image: "/televisores/samsung.jpg"
  },
  {
    id: 3,
    name: "LG UHD 50''",
    description: "Smart TV 4K con WebOS 23",
    price: "2.799.000",
    image: "/televisores/sony.jpg"
  }
];

export default products;