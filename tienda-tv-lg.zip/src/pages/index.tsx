import Navbar from '@/components/Navbar'
import HeroCarousel from '@/components/HeroCarousel'
import ProductGrid from '@/components/ProductGrid'
import Footer from '@/components/Footer'

export default function Home() {
  return (
    <div>
      <Navbar />
      <HeroCarousel />
      <ProductGrid />
      <Footer />
    </div>
  )
}