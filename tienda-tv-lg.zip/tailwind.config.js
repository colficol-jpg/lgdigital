module.exports = {
  content: ["./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: "#A50034", // rojo LG
        secondary: "#333333"
      }
    }
  },
  plugins: []
};