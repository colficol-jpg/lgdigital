export default function Home() {
  const productos = [
    { id: 1, nombre: "LG OLED C3 55”", precio: "3.499.000", img: "/tv1.jpg" },
    { id: 2, nombre: "LG NanoCell 65”", precio: "4.199.000", img: "/tv2.jpg" },
    { id: 3, nombre: "LG UHD 50”", precio: "2.199.000", img: "/tv3.jpg" },
    { id: 4, nombre: "LG OLED evo 77”", precio: "10.999.000", img: "/tv4.jpg" },
    { id: 5, nombre: "LG QNED 75”", precio: "8.499.000", img: "/tv5.jpg" },
    { id: 6, nombre: "LG LED 43”", precio: "1.599.000", img: "/tv3.jpg" },
  ];

  return (
    <main className="min-h-screen">
      <header className="flex justify-between items-center p-6 bg-black border-b border-lgRed">
        <h1 className="text-2xl font-bold text-lgRed">Tienda LG</h1>
        <nav className="flex gap-6">
          <a href="#" className="hover:text-lgRed">Inicio</a>
          <a href="#" className="hover:text-lgRed">Ofertas</a>
          <a href="#" className="hover:text-lgRed">Televisores</a>
          <a href="#" className="hover:text-lgRed">Contacto</a>
        </nav>
      </header>

      <section className="relative h-[400px] w-full bg-cover bg-center" style={{ backgroundImage: "url('/banner.jpg')" }}>
        <div className="absolute inset-0 bg-black bg-opacity-60 flex flex-col justify-center items-center text-center">
          <h2 className="text-4xl font-bold mb-4">La mejor tecnología en tus manos</h2>
          <button className="bg-lgRed px-6 py-3 rounded-lg font-semibold hover:bg-red-700">Ver ofertas</button>
        </div>
      </section>

      <section className="p-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {productos.map((tv) => (
          <div key={tv.id} className="bg-neutral-900 rounded-lg overflow-hidden shadow-lg hover:scale-105 transition-transform">
            <img src={tv.img} alt={tv.nombre} className="w-full h-60 object-cover" />
            <div className="p-4">
              <h3 className="text-xl font-semibold mb-2">{tv.nombre}</h3>
              <p className="text-lg text-lgRed mb-4">${tv.precio} COP</p>
              <button className="border border-lgRed px-4 py-2 rounded-md hover:bg-lgRed">Agregar al carrito</button>
            </div>
          </div>
        ))}
      </section>

      <footer className="bg-black border-t border-neutral-800 text-center py-6 text-sm text-gray-400">
        © 2025 Tienda LG — Todos los derechos reservados.
      </footer>
    </main>
  );
}