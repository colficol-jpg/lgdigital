export const metadata = {
  title: "Tienda LG",
  description: "Tienda digital oficial de televisores LG en oferta",
};

export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}