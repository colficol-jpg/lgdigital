# 🖥️ Tienda LG
Tienda digital de televisores LG en oferta.  
Diseñada con Next.js 14 + TailwindCSS.
